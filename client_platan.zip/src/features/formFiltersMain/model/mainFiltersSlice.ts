import { PayloadAction } from '@reduxjs/toolkit'
import { createAppSlice } from '../../../app/store/createAppSlice'
import { TypeSchemaMainFiltersForm } from './schema'
import { mainFilterDefaultValues } from '../../../shared/constants/filterDefaults'

const initialState = mainFilterDefaultValues

export const mainFiltersSlice = createAppSlice({
	name: 'mainFilters',
	initialState,
	reducers: create => ({
		updateMainFilters: create.reducer((state, action: PayloadAction<TypeSchemaMainFiltersForm>) => {
			// Обновляем каждый фильтр отдельно для избежания потери структуры
			state.freqFilter = action.payload.freqFilter
			state.pulseDurationFilter = action.payload.pulseDurationFilter
			state.pulsePeriodFilter = action.payload.pulsePeriodFilter
			state.calendarFilter = action.payload.calendarFilter
			state.selectorFilter = action.payload.selectorFilter
			state.geoFilter = action.payload.geoFilter
		}),
		addGeoArea: create.reducer(
			(
				state,
				action: PayloadAction<{ name: string; latLng: { lat: number; lng: number }[][] }>,
			) => {
				state.geoFilter.bands.push(action.payload)
			},
		),
		removeGeoArea: create.reducer((state, action: PayloadAction<number>) => {
			state.geoFilter.bands.splice(action.payload, 1)
		}),

		// Очистка всех фильтров (сброс к значениям по умолчанию)
		clearMainFilters: create.reducer(state => {
			// Сбрасываем все фильтры к initial state
			return { ...initialState }
		}),
	}),
	selectors: {
		selectMainFilters: state => state,
		selectFrequencyFilter: state => state.freqFilter,
		selectPulseDurationFilter: state => state.pulseDurationFilter,
		selectPulsePeriodFilter: state => state.pulsePeriodFilter,
		selectCalendarFilter: state => state.calendarFilter,
		selectSelectorFilter: state => state.selectorFilter,
		selectGeoAreas: state => state.geoFilter.bands,
	},
})

export const { updateMainFilters, clearMainFilters, addGeoArea, removeGeoArea } =
	mainFiltersSlice.actions
export const { selectMainFilters, selectGeoAreas } = mainFiltersSlice.selectors
