import { useEffect } from 'react'
import { useFormContext, useFieldArray } from 'react-hook-form'
import { useAppDispatch, useAppSelector } from '../../../app/store/hooks'
import { TypeSchemaMainFiltersForm } from '../model/schema'
import { ButtonDeleteFilter } from '../../../shared/buttons'
import { RiCloseLargeFill } from 'react-icons/ri'
import { removeGeoArea, selectGeoAreas } from '../model/mainFiltersSlice'

export const GeoFilterSection = () => {
	const { control } = useFormContext<TypeSchemaMainFiltersForm>()
	const dispatch = useAppDispatch()
	const geoAreas = useAppSelector(selectGeoAreas)
	const { replace } = useFieldArray({ control, name: 'geoFilter.bands' })

	// Redux → RHF синхронизация
	useEffect(() => {
		replace(geoAreas)
	}, [geoAreas])

	if (geoAreas.length === 0) {
		return (
			<p style={{ color: '#8f8f8f', fontSize: 13, padding: '8px 16px', margin: 0 }}>
				Нарисуйте область на карте.
				<br />
				Кликайте по карте, двойной клик завершает полигон.
			</p>
		)
	}

	return (
		<div>
			{geoAreas.map((area, index) => (
				<div
					key={index}
					style={{
						display: 'flex',
						alignItems: 'center',
						justifyContent: 'space-between',
						padding: '6px 16px',
						borderBottom: '1px solid rgba(255,255,255,0.06)',
					}}
				>
					<span style={{ fontSize: 14 }}>{area.name}</span>
					<span style={{ color: '#8f8f8f', fontSize: 12 }}>{area.latLng[0].length} точек</span>
					<ButtonDeleteFilter onClick={() => dispatch(removeGeoArea(index))} type="button">
						<RiCloseLargeFill />
					</ButtonDeleteFilter>
				</div>
			))}
		</div>
	)
}
