import styles from './mainMap.module.css'
import {
	MapContainer,
	TileLayer,
	Marker,
	Popup,
	useMap,
	useMapEvents,
	Polygon,
} from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import { useEffect, useRef, useState } from 'react'
import { useAppDispatch, useAppSelector } from '../../../app/store/hooks'

import { selectSideMenuOpened } from '../../../widgets/sideMenuFilters/model/sideMenuSlice'
import { LatLng } from 'leaflet'
import {
	addGeoArea,
	selectGeoAreas,
} from '../../../features/formFiltersMain/model/mainFiltersSlice'

const MapResizeFix = () => {
	const map = useMap()
	useEffect(() => {
		setTimeout(() => map.invalidateSize(), 0)
	}, [map])
	return null
}

interface PolygonDrawerProps {
	onComplete: (points: LatLng[], name: string) => void
}

// Активен только когда sideMenu открыто — клики рисуют полигон, двойной клик завершает
const PolygonDrawer = ({ onComplete }: PolygonDrawerProps) => {
	const [points, setPoints] = useState<LatLng[]>([])
	const [pendingPoints, setPendingPoints] = useState<LatLng[] | null>(null) // ждём имя
	const [popupPos, setPopupPos] = useState<LatLng | null>(null)
	const [nameInput, setNameInput] = useState('')
	const inputRef = useRef<HTMLInputElement>(null)
	useEffect(() => {
		if (popupPos) {
			setTimeout(() => inputRef.current?.focus(), 150)
		}
	}, [popupPos])

	useMapEvents({
		click(e) {
			if (pendingPoints) return // уже ждём имя — игнорируем клики
			setPoints(prev => [...prev, e.latlng])
		},
		dblclick(e) {
			e.originalEvent.preventDefault()
			if (pendingPoints) return
			if (points.length >= 3) {
				setPendingPoints(points)
				setPopupPos(e.latlng)
				setPoints([])
				setTimeout(() => inputRef.current?.focus(), 100)
			}
		},
	})

	const handleSave = () => {
		if (!pendingPoints || !nameInput.trim()) return
		onComplete(pendingPoints, nameInput.trim())
		setPendingPoints(null)
		setPopupPos(null)
		setNameInput('')
	}

	const handleCancel = () => {
		setPendingPoints(null)
		setPopupPos(null)
		setNameInput('')
	}

	return (
		<>
			{/* Рисуемый полигон */}
			{points.length >= 2 && (
				<Polygon
					positions={points.map(p => [p.lat, p.lng])}
					pathOptions={{ color: '#4fc3f7', dashArray: '6 4', fillOpacity: 0.15 }}
				/>
			)}

			{/* Завершённый но ещё не сохранённый полигон */}
			{pendingPoints && pendingPoints.length >= 3 && (
				<Polygon
					positions={pendingPoints.map(p => [p.lat, p.lng])}
					pathOptions={{ color: '#4fc3f7', fillOpacity: 0.2 }}
				/>
			)}

			{/* Popup для ввода имени */}
			{popupPos && (
				<Marker position={popupPos} opacity={0}>
					<Popup autoClose={false} closeOnClick={false} closeButton={false}>
						<div style={{ display: 'flex', flexDirection: 'column', gap: 8, minWidth: 200 }}>
							<span style={{ fontWeight: 500, fontSize: 13 }}>Название области</span>
							<input
								ref={inputRef}
								value={nameInput}
								onChange={e => setNameInput(e.target.value)}
								onKeyDown={e => {
									if (e.key === 'Enter') handleSave()
									if (e.key === 'Escape') handleCancel()
								}}
								placeholder="Введите название..."
								style={{
									padding: '4px 8px',
									border: '1px solid #ccc',
									borderRadius: 4,
									fontSize: 13,
									outline: 'none',
									color: '#111',
								}}
							/>
							<div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
								<button
									onClick={handleCancel}
									style={{ fontSize: 12, cursor: 'pointer', padding: '2px 8px' }}
								>
									Отмена
								</button>
								<button
									onClick={handleSave}
									disabled={!nameInput.trim()}
									style={{
										fontSize: 12,
										cursor: 'pointer',
										padding: '2px 8px',
										background: '#4fc3f7',
										border: 'none',
										borderRadius: 4,
										color: '#fff',
										opacity: nameInput.trim() ? 1 : 0.5,
									}}
								>
									Сохранить
								</button>
							</div>
						</div>
					</Popup>
				</Marker>
			)}
		</>
	)
}

export const MainMap = () => {
	const dispatch = useAppDispatch()
	const geoAreas = useAppSelector(selectGeoAreas)
	const sideMenuOpened = useAppSelector(selectSideMenuOpened)
	const areaCounter = geoAreas.length + 1

	const handlePolygonComplete = (points: LatLng[], name: string) => {
		dispatch(
			addGeoArea({
				name, // ← из Popup вместо автоматического
				latLng: [points.map(p => ({ lat: p.lat, lng: p.lng }))],
			}),
		)
	}

	return (
		<div className={styles.map__container}>
			<MapContainer
				center={[55.75, 37.61]}
				zoom={4}
				attributionControl={false}
				style={{ height: '100%', width: '100%', boxSizing: 'border-box' }}
				doubleClickZoom={false} // ← отключить зум по двойному клику
			>
				<MapResizeFix />
				<TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

				{/* Сохранённые области */}
				{geoAreas.map((area, i) => (
					<Polygon
						key={i}
						positions={area.latLng[0].map(p => [p.lat, p.lng])}
						pathOptions={{ color: '#4fc3f7', fillOpacity: 0.2 }}
					>
						<Popup>{area.name}</Popup>
					</Polygon>
				))}

				{/* Рисование активно только когда сайдбар открыт */}
				{sideMenuOpened && <PolygonDrawer onComplete={handlePolygonComplete} />}
			</MapContainer>

			{/* Подсказка при активном рисовании */}
			{sideMenuOpened && (
				<div
					style={{
						position: 'absolute',
						bottom: 12,
						left: '50%',
						transform: 'translateX(-50%)',
						background: 'rgba(0,0,0,0.6)',
						color: '#fff',
						padding: '4px 12px',
						borderRadius: 4,
						fontSize: 12,
						pointerEvents: 'none',
						zIndex: 1000,
					}}
				>
					Кликайте для добавления точек · Двойной клик — завершить область
				</div>
			)}
		</div>
	)
}
