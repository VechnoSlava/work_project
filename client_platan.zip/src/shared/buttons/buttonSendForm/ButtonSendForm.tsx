import { Button, ButtonProps, styled } from '@mui/material'

export const ButtonSend = styled(Button)(({ theme }) => ({
	color: theme.palette.text.secondary,
	border: `1px solid ${theme.palette.divider}`,
	borderRadius: '5px',
	'&:hover': {
		color: theme.palette.text.primary,
		borderColor: theme.palette.text.secondary,
		backgroundColor: theme.palette.action.hover,
	},
}))

export const ButtonSendForm = ({ children, ...props }: ButtonProps) => {
	return (
		<ButtonSend type="submit" variant="outlined" {...props}>
			{children}
		</ButtonSend>
	)
}
